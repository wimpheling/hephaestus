---
title: collections.Group
description: Returns a map by grouping the given page collection (slice) by a specific key.
categories: []
keywords: []
params:
  functions_and_methods:
    aliases: [group]
    returnType: page.PageGroup
    signatures: [collections.Group KEY PAGES]
aliases: [/functions/group]
---

```go-html-template
{{ $new := .Site.RegularPages | first 10 | group "New" }}
{{ $old := .Site.RegularPages | last 10 | group "Old" }}
{{ $groups := slice $new $old }}
{{ range $groups }}
  <h3>{{ .Key }}{{/* Prints "New", "Old" */}}</h3>
  <ul>
    {{ range .Pages }}
      <li>
        <a href="{{ .RelPermalink }}">{{ .LinkTitle }}</a>
        <div class="meta">{{ .Date.Format "Mon, Jan 2, 2006" }}</div>
      </li>
    {{ end }}
  </ul>
{{ end }}
```

The page group you get from `group` is of the same type you get from the built-in [group methods][] in Hugo. The example above can be [paginated][].

[group methods]: /quick-reference/page-collections/#group
[paginated]: /templates/pagination/
