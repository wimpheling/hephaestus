---
title: Introduction
description: Hugo is a static site generator written in Go, optimized for speed and designed for flexibility.
categories: []
keywords: []
weight: 10
aliases: [/about/what-is-hugo/,/about/benefits/]
---

Hugo is a [static site generator][] written in [Go][], optimized for speed and designed for flexibility. With its advanced templating system and fast asset pipelines, Hugo renders a complete site in seconds, often less.

Due to its flexible framework, multilingual support, and powerful taxonomy system, Hugo is widely used to create:

- Corporate, government, nonprofit, education, news, event, and project sites
- Documentation sites
- Image portfolios
- Landing pages
- Business, professional, and personal blogs
- Resumes and CVs

Use Hugo's embedded web server during development to instantly see changes to content, structure, behavior, and presentation. Then deploy the site to your host, or push changes to your Git provider for automated builds and deployment.

And with [modules][] you can share content, assets, data, translations, themes, templates, and configuration with other projects via public or private Git repositories.

Learn more about Hugo's [features][], [privacy protections][], and [security model][].

{{< youtube 0RKpf3rK57I >}}

[Go]: https://go.dev
[features]: /about/features/
[modules]: /hugo-modules/
[privacy protections]: /configuration/privacy/
[security model]: /about/security/
[static site generator]: https://en.wikipedia.org/wiki/Static_site_generator
