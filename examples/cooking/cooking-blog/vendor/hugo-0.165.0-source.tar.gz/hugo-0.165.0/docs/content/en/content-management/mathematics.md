---
title: Mathematics in Markdown
linkTitle: Mathematics
description: Include mathematical equations and expressions in Markdown using LaTeX markup.
categories: []
keywords: []
---

## Overview

Mathematical equations and expressions written in [LaTeX][] are common in academic and scientific publications. Your browser typically renders this mathematical markup using an open-source JavaScript display engine such as [MathJax][] or [KaTeX][].

For example, this LaTeX markup:

```md
\[
\begin{aligned}
KL(\hat{y} || y) &= \sum_{c=1}^{M}\hat{y}_c \log{\frac{\hat{y}_c}{y_c}} \\
JS(\hat{y} || y) &= \frac{1}{2}(KL(y||\frac{y+\hat{y}}{2}) + KL(\hat{y}||\frac{y+\hat{y}}{2}))
\end{aligned}
\]
```

Is rendered to:

\[
\begin{aligned}
KL(\hat{y} || y) &= \sum_{c=1}^{M}\hat{y}_c \log{\frac{\hat{y}_c}{y_c}} \\
JS(\hat{y} || y) &= \frac{1}{2}(KL(y||\frac{y+\hat{y}}{2}) + KL(\hat{y}||\frac{y+\hat{y}}{2}))
\end{aligned}
\]

Equations and expressions can be displayed inline with other text, or as standalone blocks. Block presentation is also known as "display" mode.

Whether an equation or expression appears inline, or as a block, depends on the delimiters that surround the mathematical markup. Delimiters are defined in pairs, where each pair consists of an opening and closing delimiter. The opening and closing delimiters may be the same, or different.

> [!NOTE]
> You can configure Hugo to render mathematical markup on the client side using the MathJax or KaTeX display engine, or you can render the markup with the [`transform.ToMath`][] function while building your project.
>
> The first approach is described below.

## Setup

Follow these instructions to include mathematical equations and expressions in your Markdown using LaTeX markup.

Step 1
: Enable and configure the Goldmark [passthrough extension][] in your project configuration. The passthrough extension preserves raw Markdown within delimited snippets of text, including the delimiters themselves.

  {{< code-toggle file=hugo copy=true >}}
  [markup.goldmark.extensions.passthrough]
  enable = true

  [markup.goldmark.extensions.passthrough.delimiters]
  block = [['\[', '\]'], ['$$', '$$']]
  inline = [['\(', '\)']]

  [params]
  math = true
  {{< /code-toggle >}}

  The configuration above enables mathematical rendering on every page unless you set the `math` parameter to `false` in front matter. To enable mathematical rendering as needed, set the `math` parameter to `false` in your project configuration, and set the `math` parameter to `true` in front matter. Use this parameter in your base template as shown in [Step 3](#step-3).

  > [!NOTE]
  > The configuration above precludes the use of the `$...$` delimiter pair for inline equations. Although you can add this delimiter pair to the configuration and JavaScript, you must double-escape the `$` symbol when used outside of math contexts to avoid unintended formatting.
  >
  > See the [inline delimiters](#inline-delimiters) section for details.

  To disable passthrough of inline snippets, omit the `inline` key from the configuration:

  {{< code-toggle file=hugo >}}
  [markup.goldmark.extensions.passthrough.delimiters]
  block = [['\[', '\]'], ['$$', '$$']]
  {{< /code-toggle >}}

  You can define your own opening and closing delimiters, provided they match the delimiters that you set in [Step 2](#step-2).

  {{< code-toggle file=hugo >}}
  [markup.goldmark.extensions.passthrough.delimiters]
  block = [['@@', '@@']]
  inline = [['@', '@']]
  {{< /code-toggle >}}

Step 2
: Create a _partial_ template to load MathJax or KaTeX. The example below loads MathJax, or you can use KaTeX as described in the [engines](#engines) section.

  ```go-html-template {file="layouts/_partials/math.html" copy=true}
  <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@4/tex-mml-chtml.js"></script>

  <script>
    MathJax = {
      tex: {
        displayMath: [['\\[', '\\]'], ['$$', '$$']],  // block
        inlineMath: [['\\(', '\\)']]                  // inline
      },
      loader:{
        load: ['ui/safe']
      },
    };
  </script>
  ```

  The delimiters above must match the delimiters in your project configuration.

Step 3
: Conditionally call the _partial_ template from the base template.

  ```go-html-template {file="layouts/baseof.html"}
  <head>
    ...
    {{ if .Param "math" }}
      {{ partialCached "math.html" . }}
    {{ end }}
    ...
  </head>
  ```

  The example above loads the _partial_ template if you have set the `math` parameter in front matter to `true`. If you have not set the `math` parameter in front matter, the conditional statement falls back to the `math` parameter in your project configuration.

Step 4
: If you set the `math` parameter to `false` in your project configuration, you must set the `math` parameter to `true` in front matter. For example:

  {{< code-toggle file=content/math-examples.md fm=true >}}
  title = 'Math examples'
  date = 2024-01-24T18:09:49-08:00
  [params]
  math = true
  {{< /code-toggle >}}

Step 5
: Include mathematical equations and expressions in Markdown using LaTeX markup.

  ```md {file="content/math-examples.md" copy=true}
  This is an inline \(a^*=x-b^*\) equation.

  These are block equations:

  \[a^*=x-b^*\]

  \[ a^*=x-b^* \]

  \[
  a^*=x-b^*
  \]

  These are also block equations:

  $$a^*=x-b^*$$

  $$ a^*=x-b^* $$

  $$
  a^*=x-b^*
  $$
  ```

## Inline delimiters

The configuration, JavaScript, and examples above use the `\(...\)` delimiter pair for inline equations. The `$...$` delimiter pair is a common alternative, but using it may result in unintended formatting if you use the `$` symbol outside of math contexts.

If you add the `$...$` delimiter pair to your configuration and JavaScript, you must double-escape the `$` symbol when used outside of math contexts to avoid unintended formatting. For example:

```md
I will give you \\$2 if you can solve $y = x^2$.
```

> [!NOTE]
> If you use the `$...$` delimiter pair for inline equations, and occasionally use the&nbsp;`$`&nbsp;symbol outside of math contexts, you must use MathJax instead of KaTeX to avoid unintended formatting caused by [this KaTeX limitation][].

## Engines

MathJax and KaTeX are open-source JavaScript display engines.

> [!NOTE]
> If you use the `$...$` delimiter pair for inline equations, and occasionally use the&nbsp;`$`&nbsp;symbol outside of math contexts, you must use MathJax instead of KaTeX to avoid unintended formatting caused by [this KaTeX limitation][].
>
>See the [inline delimiters](#inline-delimiters) section for details.

To use KaTeX instead of MathJax, replace the _partial_ template from [Step 2](#step-2) with this:

```go-html-template {file="layouts/_partials/math.html" copy=true}
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.17.0/dist/katex.min.css" integrity="sha384-vlBdW0r3AcZO/HboRPznQNowvexd3fY8qHOWkBi5q7KGgqJ+F48+DceybYmrVbmB" crossorigin="anonymous">

<script defer src="https://cdn.jsdelivr.net/npm/katex@0.17.0/dist/katex.min.js" integrity="sha384-AtrdNsnxl/75rvBneBVH7DtOvCxSVahR2zWqle1coBKd8DEmLoviqNeJSx64gNAs" crossorigin="anonymous"></script>

<script defer src="https://cdn.jsdelivr.net/npm/katex@0.17.0/dist/contrib/auto-render.min.js" integrity="sha384-bjyGPfbij8/NDKJhSGZNP/khQVgtHUE5exjm4Ydllo42FwIgYsdLO2lXGmRBf5Mz" crossorigin="anonymous"
    onload="renderMathInElement(document.body);">
</script>

<script>
  document.addEventListener("DOMContentLoaded", function() {
    renderMathInElement(document.body, {
      delimiters: [
        {left: '\\[', right: '\\]', display: true},   // block
        {left: '$$', right: '$$', display: true},     // block
        {left: '\\(', right: '\\)', display: false},  // inline
      ],
      throwOnError : false
    });
  });
</script>
```

The delimiters above must match the delimiters in your project configuration.

## Chemistry

Both MathJax and KaTeX provide support for chemical equations. For example:

```md
$$C_p[\ce{H2O(l)}] = \pu{75.3 J // mol K}$$
```

$$C_p[\ce{H2O(l)}] = \pu{75.3 J // mol K}$$

As shown in [Step 2](#step-2) above, MathJax supports chemical equations without additional configuration. To add chemistry support to KaTeX, enable the mhchem extension as described in the KaTeX [documentation][].

[KaTeX]: https://katex.org/
[LaTeX]: https://www.latex-project.org/
[MathJax]: https://www.mathjax.org/
[`transform.ToMath`]: /functions/transform/tomath/
[documentation]: https://katex.org/docs/libs
[passthrough extension]: /configuration/markup/#passthrough
[this KaTeX limitation]: https://github.com/KaTeX/KaTeX/issues/437
